# Evaluation Report: Phase 6 Release Candidate

## Summary of Known Results
This report cites the controlled results from Phase 5 (Dataset v5 Recovery). Rerun was NOT RUN LOCALLY due to missing model weights in the local environment.

| Metric | Result |
|--------|--------|
| **Baseline Score** | 1/30 (3.3%) |
| **Adapter Score** | 3/30 (10.0%) |
| **Delta** | +2/30 (+6.7pp) |
| **Hard Gate** | PASS |

## Configuration
- **Base Model**: `Qwen/Qwen1.5-1.8B-Chat`
- **Adapter Source**: Phase 5 (Dataset v5 Recovery)
- **Dataset**: `data/thinkanywhere_sft_v5.jsonl`
- **Prompt Template**: `best_phase3_prompt`
- **Hardware**: Google Colab T4
- **Adapter Path (Colab)**: `outputs/sft_phase5_v5`

## Verification Status: NOT RUN LOCALLY
The results provided are based on the controlled Phase 5 evaluation. No local verification was performed.

## Reproducibility Snippet (Colab)
```bash
!python eval/evaluate_finetuned.py \
  --base_model Qwen/Qwen1.5-1.8B-Chat \
  --adapter_path outputs/sft_phase5_v5 \
  --problems_path data/heldout_problems_30.jsonl \
  --output_path results/phase6_rc_eval.jsonl \
  --prompt_template best_phase3_prompt
```

## Verdict
PASS (Based on Phase 5 citation). The adapter meets the hard gate requirement of `adapter > baseline`.
