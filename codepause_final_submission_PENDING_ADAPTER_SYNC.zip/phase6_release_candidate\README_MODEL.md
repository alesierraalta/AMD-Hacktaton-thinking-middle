# CodePause Phase 6 Release Candidate Model

## Artifact Description
This artifact is a fine-tuned LoRA/QLoRA adapter for the CodePause project, designed to improve the model's ability to generate executable code while using `<thinkanywhere>` internal reasoning blocks. It was produced during Phase 5 (Dataset v5 Recovery) and is now being packaged as the Phase 6 Release Candidate.

- **Base Model**: `Qwen/Qwen1.5-1.8B-Chat`
- **Adapter Type**: LoRA/QLoRA
- **Training Environment**: Google Colab T4
- **Framework**: Transformers + TRL + PEFT + BitsAndBytes

## Provenance
- **Source Phase**: Phase 5
- **Dataset**: `data/thinkanywhere_sft_v5.jsonl`
- **Hardware**: Google Colab T4 (Official CodePause claim environment)

## Loading Instructions (NOT RUN LOCALLY)
The following snippet demonstrates how to load the base model and the adapter on a system with compatible hardware (e.g., Colab T4).

```python
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
from peft import PeftModel

base_model_id = "Qwen/Qwen1.5-1.8B-Chat"
adapter_path = "results/phase6_release_candidate/"

tokenizer = AutoTokenizer.from_pretrained(base_model_id)
base_model = AutoModelForCausalLM.from_pretrained(
    base_model_id,
    torch_dtype=torch.float16,
    device_map="auto"
)

model = PeftModel.from_pretrained(base_model, adapter_path)
```

## Evaluation Instructions
To evaluate this release candidate, use the provided evaluation scripts on the `data/heldout_problems_30.jsonl` dataset.

```bash
python eval/evaluate_finetuned.py \
  --base_model Qwen/Qwen1.5-1.8B-Chat \
  --adapter_path results/phase6_release_candidate/ \
  --problems_path data/heldout_problems_30.jsonl \
  --output_path results/phase6_rc_eval.jsonl
```

## Limitations
- **Prototype Quality**: This model is at a prototype level and is not considered production-robust.
- **Low Absolute Score**: While the adapter shows improvement over the baseline, the absolute performance (3/30) remains low.
- **AMD Disclaimer**: No AMD results are claimed for this artifact. Official validation environment is NVIDIA T4.

## Performance Summary
- **Baseline (Base + Best Prompt)**: 1/30 (3.3%)
- **Adapter (Phase 5 + Best Prompt)**: 3/30 (10.0%)
- **Delta**: +2/30
- **Hard Gate**: PASS
