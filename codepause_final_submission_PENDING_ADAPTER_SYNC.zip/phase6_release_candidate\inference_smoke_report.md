# Inference Smoke Report: Phase 6 Release Candidate

## Status: NOT RUN LOCALLY
**Provance**: Model artifacts are stored on Google Colab T4 and are not present in the local repository.

## Test Prompts

### 1. Addition
**Prompt**:
```python
# Write a function add(a, b) that returns the sum of a and b.
def add(a, b):
```

### 2. Parity Check
**Prompt**:
```python
# Write a function is_even(n) that returns True if n is even, False otherwise.
def is_even(n):
```

### 3. String Reversal
**Prompt**:
```python
# Write a function reverse_string(s) that returns the reversed string.
def reverse_string(s):
```

## Inference Procedure (Colab CPU/T4)
To run these smoke tests on Colab, use the following snippet:

```python
import torch
from transformers import AutoTokenizer, AutoModelForCausalLM
from peft import PeftModel

base_model_id = "Qwen/Qwen1.5-1.8B-Chat"
adapter_path = "results/phase6_release_candidate/" # Or Colab output path

tokenizer = AutoTokenizer.from_pretrained(base_model_id)
model = AutoModelForCausalLM.from_pretrained(base_model_id, torch_dtype=torch.float16, device_map="auto")
model = PeftModel.from_pretrained(model, adapter_path)

prompts = [
    "# Write a function add(a, b) that returns the sum of a and b.\ndef add(a, b):",
    "# Write a function is_even(n) that returns True if n is even, False otherwise.\ndef is_even(n):",
    "# Write a function reverse_string(s) that returns the reversed string.\ndef reverse_string(s):"
]

for p in prompts:
    inputs = tokenizer(p, return_tensors="pt").to("cuda")
    outputs = model.generate(**inputs, max_new_tokens=100)
    print(tokenizer.decode(outputs[0]))
```

## Verdict
NOT RUN LOCALLY. Inference validation pending Colab execution.
